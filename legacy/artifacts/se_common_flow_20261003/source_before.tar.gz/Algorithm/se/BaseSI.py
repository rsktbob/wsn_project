"""Selected-scope investment flow, independent of the full-region SA flow."""
from __future__ import annotations
import numpy as np
from Algorithm.se.BaseSE import BaseSE
from Algorithm.se.market_components import PooledEvaluation, AdaptiveBetaMemory
from Algorithm.se.population_updates import searchers_from_goods, goods_from_children


class BaseSI(PooledEvaluation, AdaptiveBetaMemory, BaseSE):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._pool = None
        self.goods = []
        self.goods_fitness = np.empty((self.h, self.w), dtype=float)
        self.investment_quality = np.empty((self.h, self.n), dtype=float)

    def initialize_market(self, problem, initial_state=None):
        super().initialize_market(problem, initial_state)
        self.goods = [[self.create_candidate(problem, region=region)
                       for _ in range(self.w)] for region in range(self.h)]
        flat = [good for group in self.goods for good in group]
        self.goods_fitness = self.evaluate_many(problem, flat).reshape(self.h, self.w)
        self.investment_quality = np.repeat(
            np.mean(self.goods_fitness, axis=1)[:, None], self.n, axis=1)

    def make_offspring(self, problem, searcher, good, region):
        return (self.align_region(problem, self.invest(problem, searcher, good), region),)

    def goods_for_region(self, region):
        return self.goods[int(region)]

    def create_investments(self, problem, active_regions):
        return [
            [child for good in self.goods_for_region(region)
             for child in self.make_offspring(problem, self.searchers[searcher_id],
                                               good, int(region))]
            for searcher_id, region in enumerate(active_regions)]

    def summarize_round(self, active_regions, scores):
        for searcher_id, region in enumerate(active_regions):
            self.investment_quality[int(region), searcher_id] = float(
                np.mean(scores[searcher_id]))
        return self.investment_quality

    def update_searchers(self, children, scores, selected, goods_before):
        searchers_from_goods(self, self.goods, goods_before, selected)

    def update_goods(self, children, scores, active_regions):
        for region in range(self.h):
            goods_from_children(self.goods[region], self.goods_fitness[region],
                                children, scores, np.flatnonzero(active_regions == region))

    def vision_search(self, problem):
        progress = min(1.0, self.evatime / max(1, self.evaluation_limit))
        self.current_adaptive_step = self.adaptive_step * (1.0 - progress)
        active_regions = self.selected_regions.copy()
        goods_before = self.goods_fitness.copy()
        children = self.create_investments(problem, active_regions)
        width = len(children[0])
        flat = [child for row in children for child in row]
        scores = self.evaluate_many(problem, flat, batch_size=width).reshape(self.n, width)
        # Keep worker-returned candidates, including any decoder caches.
        children = [flat[i * width:(i + 1) * width] for i in range(self.n)]
        quality = self.summarize_round(active_regions, scores)
        selected = self.select_regions(self.region_probabilities(goods_before, quality))
        self.update_searchers(children, scores, selected, goods_before)
        self.update_goods(children, scores, active_regions)
        self.selected_regions = selected
