"""Single-offspring, selected-region SETS; no inheritance from SA_SETS."""
import numpy as np
from Algorithm.se.BaseSI import BaseSI
from Algorithm.se.sensor_operators import SensorOperators, AdaptiveSensorInitialization
from Algorithm.se.market_components import beta_cdf


class SI_SETS(AdaptiveSensorInitialization, SensorOperators, BaseSI):
    def __init__(self, problem, n=5, h=4, w=8, mu=0.2, seed=None):
        super().__init__(problem, n=n, h=h, w=w, mu=mu, seed=seed)

    def region_probabilities(self, goods_fitness, investment_quality):
        """Use current observations and cached values to score every pool."""
        average_goods = np.mean(goods_fitness, axis=1)
        best_goods = np.max(goods_fitness, axis=1)
        total = float(np.sum(average_goods))
        if abs(total) <= np.finfo(float).eps:
            region_share = np.full(self.h, 1.0 / self.h)
        else:
            region_share = average_goods / total

        expected_value = (
            best_goods[:, None]
            * investment_quality
            * region_share[:, None]
        )
        probability = np.empty((self.h, self.n), dtype=float)
        for region in range(self.h):
            for searcher_id in range(self.n):
                probability[region, searcher_id] = beta_cdf(
                    self.ta[region],
                    self.tb[region],
                    expected_value[region, searcher_id],
                )
        return probability

__all__ = ["SI_SETS"]
