"""Full-region investment flow; goods are updated after searchers."""
from Algorithm.se.BaseSE import BaseSE
from Algorithm.se.parallel_market import ParallelSEMarket
from Algorithm.se.population_updates import searchers_from_goods, goods_from_children


class BaseSA(BaseSE):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.market = ParallelSEMarket(self)

    def arrange_resources(self, problem):
        self.market.start(problem)

    def vision_search(self, problem):
        build_contexts = getattr(self, "build_market_contexts", None)
        contexts = build_contexts(problem) if callable(build_contexts) else None
        goods, scores, investment_scores, evaluations = self.market.search(
            self.searchers, contexts=contexts
        )
        self.evatime += evaluations
        probabilities = self.region_probabilities(scores, investment_scores)
        selected = self.select_regions(probabilities)
        self.update_searchers(self.market.investments, investment_scores, selected, scores)
        # Exactly the SI ordering: old goods -> searchers -> new goods.
        self.update_goods(self.market.investments, investment_scores, self.selected_regions)
        self.selected_regions = selected
        finish = getattr(self, "on_market_round_finish", None)
        if callable(finish):
            finish(problem, goods, scores, investment_scores, selected)

    def update_searchers(self, children, scores, selected, goods_before):
        searchers_from_goods(self, self.market.goods, goods_before, selected)

    def update_goods(self, children, scores, active_regions):
        # Full investment: all searchers visit every region. The argument
        # names match BaseSI; active_regions never restricts this family's FE.
        for region_id, region in enumerate(self.market.regions):
            goods_from_children(
                self.market.goods[region_id], self.market.goods_fitness[region_id],
                children[region_id], scores[region_id], range(self.n),
                accept=getattr(region, "accept_good_replacement", None))
        self.goods = self.market.goods
        self.goods_fitness = self.market.goods_fitness

    def close_market(self):
        self.market.close(self.searchers)
