# WSN 精確方法與 CP-SAT 文獻調查

調查日期：2026-10-01。主題：精確最佳化是否已用於 WSN，以及與 100 顆感測器、0／1／2 排層問題的關係。

## 1. 結論與查證範圍

有。已核實 WSN 使用限制式規劃（CP）、SAT／SMT、ILP／MILP、列生成（column generation）的論文，涵蓋可調感測範圍、覆盖與連通、休眠排程、中繼配置及網路生命週期。

但這些名稱不能互換。Google OR-Tools CP-SAT 是特定求解器；使用 CP、SAT 或 OR-Tools 的文章，不能直接說成使用 CP-SAT。本次尚未核實到明確以 Google CP-SAT 求解與本專案相同的「感測排層＋覆蓋＋路由」問題之論文。這是檢索限制，不是不存在相關研究的證明，也不能據此宣稱首次應用。

本次主要查閱出版商摘要／可見段落、作者機構典藏與公開全文；未取得所有文章全文，因此不報告未核實的實驗規模、最優率或加速倍數。以下各項標明證據層級。

## 2. 優先閱讀的論文

### A. 可調感測範圍：與 0／1／2 排層最接近

**André Rossi, Alok Singh, Marc Sevaux (2012). An exact approach for maximizing the lifetime of sensor networks with adjustable sensing ranges. Computers & Operations Research, 39, 3166–3176.**

- [DOI](https://doi.org/10.1016/j.cor.2012.04.001)
- [公開全文](https://cedric.cnam.fr/~bentzc/INITREC/Files/CB5.pdf)
- 問題：可調感測半徑下，維持目標覆蓋並最大化生命週期。研究連續可調與預先指定離散半徑兩種版本。
- 方法：列生成精確框架，結合 GA 加速子問題搜尋；本文不是 Google CP-SAT 應用。
- 與專案關係：關閉、低排層、高排層可對應到關閉與兩個非零預設感測範圍。這是概念映射，並非作者恰好使用本專案的三態設定。
- 差異：本文研究多個覆蓋集合的啟用時長與電量配置；不能直接把其生命週期最佳解等同於單輪最小能耗。也不能據此宣稱已包含本專案完整路由或無線干擾模型。
- 查證：公開全文的問題定義、摘要與模型說明。

### B. 真正的限制式規劃應用：中繼配置與容錯

**Luis Quesada, Lanny Sitanayah, Kenneth N. Brown, Barry O’Sullivan, Cormac J. Sreenan (2015). A constraint programming approach to the additional relay placement problem in wireless sensor networks. Constraints, 20(4), 433–451.**

- [DOI](https://doi.org/10.1007/s10601-015-9188-8)
- [作者機構紀錄與摘要](https://research.ucc.ie/en/publications/a-constraint-programming-approach-to-the-additional-relay-placeme-3/)
- 問題：節點故障後仍有到 sink 的替代路徑，且路徑長度受限；研究需要增加哪些中繼。
- 方法：以 CP 判斷 strongly k-robustness，並以 QuickXplain 擴展中繼集合搜尋，與 MIP／局部搜尋比較。
- 意義：證明 CP 已用於 WSN 網路結構與容錯限制，不只是泛稱「可以使用」。
- 限制：摘要中的 minimal relay set 不能直接當成已證明 minimum-cardinality 的中繼集合；最小包含集合與全域最少顆數不同。亦不能把 CP 稱為 Google CP-SAT。
- 查證：機構摘要與正式書目，未完成全文算法證明審查。

### C. SAT／SMT 直接最佳化休眠排程

**Gergely Kovásznai, Krisztián Gajdár, Laura Kovács (SYNASC 2019). Portfolio SAT and SMT Solving of Cardinality Constraints in Sensor Network Optimization. Proceedings, pp. 85–91.**

- [DOI](https://doi.org/10.1109/SYNASC49474.2019.00021)
- [作者機構紀錄](https://research.chalmers.se/publication/517214)
- [TU Wien 公開稿](https://repositum.tuwien.at/bitstream/20.500.12708/16308/5/Kovasznai-2020-Portfolio%20SAT%20and%20SMT%20Solving%20of%20Cardinality%20Constraints%20in...-am.pdf)
- 問題：在覆蓋、電池與可靠性／安全限制下，安排感測器睡眠與喚醒，最大化生命週期。
- 方法：以布林基數限制建模，結合 SAT 與 SMT 求解；論文分析 MiniCARD＋Z3 等組合。
- 與專案關係：很適合參考「每個目標至少由 K 顆感測器覆蓋」及多時段啟用限制的表達方式。
- 限制：這是 SAT／SMT 組合，不是 Google CP-SAT；其效能結論限於文中實驗，不能外推到本專案。
- 查證：機構紀錄及公開稿摘要／問題定義。採會議年份 2019，避免與後續出版或典藏年份混淆。

### D. 覆蓋與連通整合：MILP 與列生成

**Jean-Claude Charr, Karine Deschinkel, Rania Haj Mansour, Mourad Hakem (2022). Partial coverage optimization under network connectivity constraints in heterogeneous sensor networks. Computer Networks, 210, 108928.**

- [DOI](https://doi.org/10.1016/j.comnet.2022.108928)
- [出版商摘要](https://www.sciencedirect.com/science/article/abs/pii/S1389128622001165)
- 問題：異質 WSN 中，在連通限制下最大化生命週期；同時考慮整體部分覆蓋，以及個別目標在生命週期中的最低覆蓋時間比例。
- 方法：MILP、列生成、專用啟發式子問題求解，必要時使用精確 ILP 子問題。
- 與專案關係：避免只有幾何覆蓋卻無法把資料送到基地台；亦可參考多時段服務品質限制。
- 注意：部分覆蓋比例和單一感測器的排層編號是不同概念。列生成框架的精確性需要依照本文的模型與終止條件判斷，不能把任意列生成程式都叫精確方法。
- 查證：出版商摘要及可見章節；未核實全文各組實驗數據。

### E. 精確方法和 GA 可以結合

**Alok Singh, André Rossi (2013). A genetic algorithm based exact approach for lifetime maximization of directional sensor networks. Ad Hoc Networks, 11(3), 1006–1021.**

- [DOI](https://doi.org/10.1016/j.adhoc.2012.11.004)
- [出版商摘要](https://www.sciencedirect.com/science/article/abs/pii/S1570870512002077)
- 問題：方向性感測器一次只能監測一個角度區域，安排工作方式以延長生命週期。
- 方法：列生成，以 GA 與 ILP 組合求解輔助問題；ILP 用來跳出局部限制或證明當前解的最優性。
- 意義：演算法包含 GA，不代表整體必然失去精確保證。保證來自完整框架的精確求解與終止機制，不是 GA 本身。
- 差異：本文控制方向；本專案控制感測範圍排層，不能當成同一個決策模型。
- 查證：出版商書目與摘要。

### F. 近期整合研究：2026 年 MILP／Gurobi

**Esra Çelik, Muhammed Emre Keskin (2026). Wireless sensor network design with reliable and long network lifetime. Scientific Reports, 16, 12458. Published 14 April 2026.**

- [正式論文](https://doi.org/10.1038/s41598-026-46014-x)
- [作者機構摘要](https://avesis.atauni.edu.tr/yayin/0e68107e-ab64-42ac-b4fd-8156d311192f/wireless-sensor-network-design-with-reliable-and-long-network-lifetime)
- 問題：整合覆蓋、sink 配置／移動、感測器活動排程、資料路由與可靠性。
- 方法：建立 MILP，以 Gurobi 求解；另提出 Lagrangian heuristic 與 Dantzig–Wolfe 列生成處理大型案例。
- 實驗條件：原文可見段落載明 i7-4770、8 GB RAM；三種模型比較給每案例最多三小時。此條件不能直接推算本專案的可解感測器數。
- 判讀：限時下啟發式可能取得比求解器更好的可行解；這不等於勝過已證明的全域最佳值。
- 重現資源：原文列出 [資料與程式典藏](https://doi.org/10.5281/zenodo.19135285)，本次未下載或執行。
- 查證：出版商索引可見的模型、實驗與資料可用性段落，並以作者機構紀錄交叉確認。

## 3. 補充資料與容易誤引的情況

### OR-Tools 不等於 CP-SAT

**Maher Rebai, Jinane Charafeddine, Taha Houda, Wafaa Shakir. Path Optimization for Mobile Sensors to Monitor Coverage Holes in Wireless Sensor Networks.**

[出版單位公開 PDF](https://aircconline.com/csit/papers/vol15/csit151306.pdf)

該文提出移動感測器路徑的 BILP，正文明確提到 Python、OR-Tools 及 3600 秒求解上限。已讀取的全文文字中沒有找到 CP-SAT，未核實 backend，因此只能把它列為 OR-Tools／整數規劃相關證據，不能當成明確的 CP-SAT 論文。其路徑問題也不同於固定感測器排層。

### 同名博士論文公告不是完整研究論文

**Farshid Hassani Bijarbooneh (2015). Constraint Programming for Wireless Sensor Networks. Uppsala University, doctoral thesis.**

[大學典藏全文](https://uu.diva-portal.org/smash/get/diva2%3A778823/FULLTEXT01.pdf)

適合追蹤 CP 在 WSN 的研究脈絡，包含覆蓋、移動、資料蒐集與任務配置等。Constraints 20:508、DOI 10.1007/s10601-015-9228-4 的同名紀錄是一頁博士論文公告，不能將它當作詳細算法與實驗來源。

## 4. 對本專案的建模建議（本次分析，非上述論文既有結論）

先建立可與現有評分一致的單輪基準，再逐步加入路由與時間。

### 單輪三態覆蓋模型

令 z[i,l] 為二元變數，表示感測器 i 選擇排層 l，l 屬於 {0,1,2}。

- 每顆只選一層：sum_l z[i,l] = 1。
- 事先計算 cover[i,l,j]：感測器 i 在 l 層是否覆蓋目標 j。
- 每個目標至少覆蓋 k[j] 次：sum_i,l cover[i,l,j] * z[i,l] >= k[j]。
- 基本能耗目標：min sum_i,l energy[i,l] * z[i,l]。

100 顆使用完整 one-hot 時有 300 個選層布林變數；這只是選層部分，不包括路由、連通或時間輔助變數。CP-SAT 也可以使用 100 個三值整數變數搭配查表／布林限制；表面變數較少不保證執行較快。

cover 是每顆感測器在每層對目標的局部關係，不是列出 3^100 個完整網路方案。若感測成功率本身取決於其他節點的同時活動或 SINR，這個固定覆蓋矩陣模型便不足，需另建耦合限制。

### 模型選擇

- 排層、邏輯條件、離散時槽：CP-SAT 值得測試。
- 連續流量、連續啟用時長：MILP 通常更直接；CP-SAT 不直接提供連續決策變數，需要離散化，且保證僅對離散模型成立。
- 巨量覆蓋集合的排程：參考列生成；只有啟發式找不到改善列，並不構成沒有改善列的證明。
- 固定路由的能耗代理模型，只能證明該代理模型的最佳值。要與完整 WSN 比較，必須統一目標與可行條件，並回到完整評估器驗證。

### 實驗應記錄

同一張地圖、同一模型、相同時間預算下，比較現有啟發式、CP-SAT／MILP，以及欲提出的方法。記錄最佳可行值、best bound、gap、狀態、首次可行時間與总時間。小型案例用枚舉交叉驗證模型；大型案例即使沒有證明最佳，界限仍可提供品質參考。

精確方法的 OPTIMAL／gap 也受設定容許值與數值處理影響；浮點能耗縮放成整數時需記錄尺度與誤差。[CP-SAT 官方說明](https://developers.google.com/optimization/cp/cp_solver)

## 5. 對碩士貢獻的判斷

單純「把既有 WSN 模型交給精確求解器」已有大量前例，不能只靠換成 CP-SAT 就宣稱重大創新。較具體的研究方向包括：

1. 更貼近本專案的排層、路由、能量與時間耦合模型。
2. 有證據的建模／編碼改進，使求解或證明界限更有效率。
3. 結合啟發式與精確子問題，並清楚區分解品質和最優性保證。
4. 對量子／量子啟發式建立相同條件的強基準，量化何時有效、何時沒有優勢。

閱讀順序建議：A（離散半徑）→ D（覆蓋＋連通）→ F（整合路由與可靠性）→ C、B（邏輯與限制式求解）→ E（混合框架）。
