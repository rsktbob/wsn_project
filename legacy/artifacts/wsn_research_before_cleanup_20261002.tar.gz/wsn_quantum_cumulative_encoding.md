# WSN 量子啟發式累積編碼設計

## 1. 設計目標

針對 WSN / MWSN 中每個 sensor 的排層決策，假設每個 sensor 可選擇：

\[
L_i \in \{0,1,2,3,4,5\}
\]

其中 \(L_i\) 代表第 \(i\) 個 sensor 所處的 layer。

因為 layer 具有明確的順序關係：

\[
0 < 1 < 2 < 3 < 4 < 5
\]

因此不希望將六個 layer 單純視為彼此完全獨立的 category，而希望編碼本身能保留「相鄰 layer 比較接近」的結構。

---

## 2. 累積式 Binary Encoding

每個 layer 使用 6 個 bit 表示：

| Layer | Encoding |
|---:|:---|
| 0 | `100000` |
| 1 | `110000` |
| 2 | `111000` |
| 3 | `111100` |
| 4 | `111110` |
| 5 | `111111` |

也就是：

\[
L_i = k
\]

對應：

\[
x_{ij} =
\begin{cases}
1, & j \le k+1\\
0, & j > k+1
\end{cases}
\]

例如：

\[
L_i=2
\]

則：

\[
X_i=[1,1,1,0,0,0]
\]

也就是：

```text
111000
```

---

## 3. 為什麼使用這種編碼

這種編碼能直接保留 layer 之間的距離關係。

例如：

```text
Layer 2 = 111000
Layer 3 = 111100
```

只差一個 bit。

因此：

\[
d_H(L_2,L_3)=1
\]

其中 \(d_H\) 為 Hamming distance。

但：

```text
Layer 2 = 111000
Layer 5 = 111111
```

相差三個 bit：

\[
d_H(L_2,L_5)=3
\]

因此：

\[
d_H(L_a,L_b)=|a-b|
\]

這表示：

\[
|2-3| < |2-5|
\]

會自然反映在 binary representation 上。

這對 WSN 的 layer decision 很重要，因為 layer 並不是六個完全沒有關係的類別，而是具有 ordinal / hierarchical structure。

---

# 4. 100 個 Sensor 的完整編碼

假設：

\[
N=100
\]

每個 sensor 使用 6 個位置，因此完整 representation 為：

\[
X \in \{0,1\}^{100\times6}
\]

也可以攤平成：

\[
X \in \{0,1\}^{600}
\]

例如：

```text
Sensor 1 : 111000
Sensor 2 : 100000
Sensor 3 : 111111
Sensor 4 : 110000
...
Sensor 100: 111100
```

對應的 layer solution：

\[
L=[2,0,5,1,\ldots,3]
\]

---

# 5. 合法狀態限制

每個 sensor 並不是任意的 6-bit pattern 都可以接受。

合法狀態只有：

```text
100000
110000
111000
111100
111110
111111
```

例如以下狀態都是非法的：

```text
101000
101100
010000
110100
111010
```

因此：

\[
X_i \notin \{0,1\}^6
\]

任意狀態集合，而是：

\[
X_i \in \mathcal{S}
\]

其中：

\[
\mathcal{S}
=
\{
100000,
110000,
111000,
111100,
111110,
111111
\}
\]

---

# 6. 量子啟發式表示

每一個 binary position 不直接存固定的 0 或 1，而是使用一個 qubit-inspired probability state：

\[
q_{ij}
=
\begin{bmatrix}
\alpha_{ij}\\
\beta_{ij}
\end{bmatrix}
\]

其中：

\[
|\alpha_{ij}|^2+|\beta_{ij}|^2=1
\]

並定義：

\[
P(x_{ij}=0)=|\alpha_{ij}|^2
\]

\[
P(x_{ij}=1)=|\beta_{ij}|^2
\]

因此第 \(i\) 個 sensor 可以寫成：

\[
Q_i=
[q_{i1},q_{i2},q_{i3},q_{i4},q_{i5},q_{i6}]
\]

100 個 sensor：

\[
Q=
\{Q_1,Q_2,\ldots,Q_{100}\}
\]

總共具有：

\[
100\times6=600
\]

個 quantum-inspired binary positions。

---

# 7. 初始化

最簡單的初始化方式是讓每個 bit 的 0 / 1 機率相同：

\[
\alpha_{ij}
=
\beta_{ij}
=
\frac{1}{\sqrt2}
\]

因此：

\[
P(0)=P(1)=0.5
\]

也就是：

\[
q_{ij}
=
\begin{bmatrix}
1/\sqrt2\\
1/\sqrt2
\end{bmatrix}
\]

不過，由於本設計只有 6 種合法 cumulative states，如果每一個 bit 完全獨立測量，會產生大量非法狀態。

所以實際演算法不能只做單純的獨立 bit sampling，還需要合法化策略。

---

# 8. Measurement

對每個 position \(q_{ij}\)：

產生：

\[
r\sim U(0,1)
\]

若：

\[
r < |\beta_{ij}|^2
\]

則：

\[
x_{ij}=1
\]

否則：

\[
x_{ij}=0
\]

例如測量後得到：

```text
111010
```

但：

```text
111010
```

不是合法狀態，因此需要進一步 decode / repair。

---

# 9. 合法化方法

## 方法 A：Prefix Repair

由左至右讀取。

只允許：

```text
111...1100...00
```

也就是一旦出現第一個 `0`，後面的 bit 全部強制設成 `0`。

例如：

```text
111010
```

repair：

```text
111000
```

因此：

\[
111010\rightarrow111000
\]

最後：

\[
L_i=2
\]

另一個例子：

```text
110111
```

repair：

```text
110000
```

因此：

\[
L_i=1
\]

---

## 方法 B：Nearest Valid State

測量後產生 binary vector：

\[
Y_i
\]

然後尋找與它 Hamming distance 最小的合法 pattern：

\[
X_i^*
=
\arg\min_{S_k\in\mathcal S}
d_H(Y_i,S_k)
\]

例如：

```text
Y = 111010
```

合法候選：

```text
100000
110000
111000
111100
111110
111111
```

計算 Hamming distance 後，選擇最近的合法狀態。

---

# 10. 更適合的直接解碼方式

比起「先產生非法 6-bit，再修復」，另一個更乾淨的方法是直接從 quantum state 推導 layer。

例如定義每個位置被啟動的傾向：

\[
p_{ij}=|\beta_{ij}|^2
\]

然後利用 cumulative structure 決定 layer。

例如：

\[
P(L_i\ge j)
\]

由第 \(j\) 個位置的啟動概率表示。

因為：

```text
Layer 0 = 100000
Layer 1 = 110000
Layer 2 = 111000
...
```

所以：

\[
x_{ij}=1
\]

可以解釋為：

> sensor \(i\) 至少達到某一個 layer threshold。

這種 interpretation 與 ordinal encoding 很接近。

---

# 11. Quantum Rotation Update

如果使用 Quantum-inspired Evolutionary Algorithm，可使用 rotation gate 更新 qubit：

\[
\begin{bmatrix}
\alpha'\\
\beta'
\end{bmatrix}
=
\begin{bmatrix}
\cos\theta & -\sin\theta\\
\sin\theta & \cos\theta
\end{bmatrix}
\begin{bmatrix}
\alpha\\
\beta
\end{bmatrix}
\]

其中：

\[
\theta=\Delta\theta
\]

依據：

- current solution
- best solution
- fitness improvement
- target bit

決定旋轉方向。

如果希望某一 position 更容易變成 1：

\[
|\beta|^2 \uparrow
\]

反之，如果希望更容易變成 0：

\[
|\alpha|^2 \uparrow
\]

---

# 12. Layer Update 的意義

假設目前 sensor \(i\) 為：

```text
111000
```

即：

\[
L_i=2
\]

若最佳解暗示應該往 layer 3 移動：

```text
111000
   ↓
111100
```

只需要增加第 4 個 position 成為 1 的概率。

因此更新可以是局部的。

而從：

\[
L_i=2
\]

移動到：

\[
L_i=5
\]

需要：

```text
111000
→ 111100
→ 111110
→ 111111
```

這會形成一種自然的 gradual search。

---

# 13. 與直接整數編碼比較

傳統編碼：

\[
L_i\in\{0,1,2,3,4,5\}
\]

例如：

```text
[2,0,5,1,...]
```

優點：

- representation 簡單
- memory 少
- decode 快

但演算法本身需要另外定義「2 和 3 比 2 和 5 更接近」。

---

累積式 encoding：

```text
0 → 100000
1 → 110000
2 → 111000
3 → 111100
4 → 111110
5 → 111111
```

本身就有：

\[
d_H(L_a,L_b)=|a-b|
\]

因此 ordinal relationship 被直接嵌入 representation。

---

# 14. 與 One-hot Encoding 比較

如果使用 one-hot：

```text
Layer 0 = 100000
Layer 1 = 010000
Layer 2 = 001000
Layer 3 = 000100
Layer 4 = 000010
Layer 5 = 000001
```

則：

\[
d_H(L_0,L_1)=2
\]

而：

\[
d_H(L_0,L_5)=2
\]

也就是：

\[
d_H(L_0,L_1)
=
d_H(L_0,L_5)
\]

因此 one-hot 無法表達 layer 的距離。

這也是累積式 encoding 的主要優點之一。

---

# 15. 與直接 6-State Quantum Encoding 的差異

另一種設計是：

\[
|\psi_i\rangle
=
\alpha_{i0}|0\rangle+
\alpha_{i1}|1\rangle+
\cdots+
\alpha_{i5}|5\rangle
\]

其中：

\[
P(L_i=k)=|\alpha_{ik}|^2
\]

這是直接把 0～5 當成六個 quantum-inspired states。

但在 basis representation 中：

\[
\langle2|3\rangle=0
\]

而：

\[
\langle2|5\rangle=0
\]

因此：

\[
|2\rangle
\]

和：

\[
|3\rangle
\]

並不天然比：

\[
|5\rangle
\]

更接近。

相比之下，累積式 encoding：

```text
2 = 111000
3 = 111100
5 = 111111
```

具有：

\[
d_H(2,3)=1
\]

\[
d_H(2,5)=3
\]

更符合 WSN layer variable 的 ordinal 特性。

---

# 16. Sensor 之間的 Interaction 問題

目前這種 encoding 解決的是：

> 每個 sensor 自己的 layer representation。

但如果每個 sensor 的 quantum state 都獨立：

\[
P(L_1,L_2,\ldots,L_N)
=
\prod_iP(L_i)
\]

則無法直接表示 sensor 之間的 dependence。

例如：

> Sensor A 在 layer 2 時，Sensor B 在 layer 4 特別好。

單純 independent encoding 無法直接學習這種 joint relationship。

---

# 17. 未來可加入 Local Interaction

為了保留 sensor 之間的 interaction，可以只針對：

- coverage overlap
- spatial neighbors
- routing neighbors
- same cluster
- interference neighbors

建立局部關係。

例如：

\[
P(L_i,L_j)
\]

而不是建立完整：

\[
P(L_1,L_2,\ldots,L_{100})
\]

因為完整 joint state 會有：

\[
6^{100}
\]

種可能，完全不可行。

因此較合理的架構是：

\[
\boxed{
\text{Cumulative Quantum Encoding}
+
\text{Local Sensor Interaction}
}
\]

---

# 18. 與目前 WSN Decoder 的整合

完整流程：

\[
Q
\]

↓

Quantum Measurement

\[
Y
\]

↓

Validity Repair / Cumulative Decode

\[
X
\]

↓

Layer Decode

\[
L=[L_1,L_2,\ldots,L_{100}]
\]

↓

原本 WSN Decoder

- coverage calculation
- redundant sensor removal
- active sensor determination
- routing
- energy calculation

↓

Fitness

\[
f(L)
\]

↓

Quantum Update

\[
Q^{t+1}
\]

整體：

\[
\boxed{
Q^t
\rightarrow
Measurement
\rightarrow
Repair
\rightarrow
Layer
\rightarrow
WSN Decoder
\rightarrow
Fitness
\rightarrow
Quantum Update
\rightarrow
Q^{t+1}
}
\]

---

# 19. 核心設計總結

本設計不是把 layer 單純表示成：

```text
0,1,2,3,4,5
```

也不是 one-hot：

```text
100000
010000
001000
...
```

而是使用 cumulative representation：

```text
0 = 100000
1 = 110000
2 = 111000
3 = 111100
4 = 111110
5 = 111111
```

核心優點：

1. 保留 layer 順序。
2. Hamming distance 對應 layer distance。
3. 相鄰 layer 可以透過局部 bit change 搜尋。
4. 可以套用 quantum-inspired probability / rotation update。
5. 能與目前 WSN decoder 分離，原本 fitness 不需要大幅修改。
6. 後續可以進一步加入 local sensor interaction。

核心限制：

1. 6-bit 空間中只有 6 種合法 pattern。
2. 獨立 qubit measurement 可能產生非法 pattern。
3. 需要 repair 或 constraint-aware measurement。
4. 若 sensor 完全獨立，仍無法直接學習 sensor interaction。
5. 如果只有概率而沒有 rotation / interference / correlation 等機制，可能被質疑只是概率編碼換形式。

---

# 20. 最終表示

對 sensor \(i\)：

\[
Q_i=
[q_{i1},q_{i2},q_{i3},q_{i4},q_{i5},q_{i6}]
\]

其中：

\[
q_{ij}
=
\alpha_{ij}|0\rangle+
\beta_{ij}|1\rangle
\]

測量並合法化後：

\[
X_i\in
\{
100000,
110000,
111000,
111100,
111110,
111111
\}
\]

最後：

\[
L_i
=
\left(\sum_{j=1}^{6}X_{ij}\right)-1
\]

例如：

\[
X_i=111100
\]

則：

\[
\sum_j X_{ij}=4
\]

因此：

\[
L_i=4-1=3
\]

所以可以非常簡單地從 cumulative encoding 還原 layer：

\[
\boxed{
L_i=\sum_j X_{ij}-1
}
\]

這就是目前這版量子啟發式 WSN layer encoding 的核心設計。
