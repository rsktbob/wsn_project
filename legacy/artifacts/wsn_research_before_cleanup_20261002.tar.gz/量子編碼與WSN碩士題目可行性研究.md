# 量子編碼、WSN 碩士題目與現有硬體可行性研究

> 2026-10-01 查核更新：請先讀 [量子編碼全覽與研究缺口修訂](./量子編碼全覽與研究缺口修訂.md)。新版補充資料載入、壓縮式最佳化、三態成對成本的二次表示及硬體估算的適用條件。

研究日期：2026-10-01（臺灣時間）。對象：本專案的無線感測網路（WSN）感測等級、覆蓋、路由與網路壽命最佳化。

## 一、先給結論

**可以形成有貢獻的碩士題目，但貢獻要放在「有序多值決策的編碼、限制處理、分區混合最佳化與嚴格實驗」，不能只把既有演算法加上「量子」名稱。**本專案已有真實的覆蓋與路由評估器、100 sensor／100 target 地圖、感測等級 QUBO 子問題，以及溫度計與 one-hot 兩種實作，足以支撐可重現的比較研究。現有機器適合大型**量子啟發式的經典模擬**、QUBO 的經典退火及小型 QAOA 電路模擬；不適合以完整 100 sensor 排程做精確量子狀態向量模擬。

**首推題目**：「面向 WSN 感測等級與路由限制的混合進制／有序編碼 QUBO 分區最佳化」。重點是比較 compact binary、Gray、one-hot、thermometer/domain-wall、三進制與混合進制在相同原始目標和計算預算下的可行率、解品質、時間與 QUBO 規模，然後在關鍵區域使用局部子問題求解，再交回完整 WSN 解碼與壽命模擬。QAOA 可作 8–20 個演算法 qubit的探索性補充，不能作論文成敗的唯一支柱。2026 年的量子最佳化基準工作特別強調可比較的實例、強經典基線與未成功結果的報告。[來源：The Quantum Optimization Benchmarking Library](https://www.nature.com/articles/s43588-026-00991-1)

## 二、用詞與研究邊界

| 名稱 | 這裡的意義 | 需要量子硬體？ | 100 sensor 可行性 |
|---|---|---:|---|
| 傳統二進制／三進制編碼 | 以 bit／trit 表示 sensor 等級；解碼與搜尋仍在 CPU/GPU | 否 | 可行 |
| 量子啟發式演算法（QEA/QIGA） | 用複振幅或等價機率參數抽樣，再用經典規則更新；本質上仍是經典隨機搜尋 | 否 | 可行，應與一般機率模型比較 |
| QUBO／Ising | 把有限決策與限制寫成二次 0/1 目標；可交給經典退火、數位 Ising 機或量子退火器 | 否，除非選量子退火器 | 可做局部或全域的經典 QUBO，需考慮稠密矩陣成本 |
| QAOA／量子閘電路 | qubit 上實作成本相位與 mixer；本機只能模擬小電路 | 真機實驗才需要 | 直接完整基底 statevector 不可行；局部或壓縮表示可研究 |
| qutrit／qudit | 真正的三態／d 態量子系統，不等同於在二進制電腦上存三進位 | 真機才有實體 qutrit | 可作小型數值研究，非現有 GPU 直接提供 |

Qutrit 的基態是 $|0\rangle, |1\rangle, |2\rangle$，一般態有三個複振幅；它**不是**一般程式的 `0/1/2` 整數，也不是三個獨立 qubit。多態量子 QAOA 已有針對圖著色和充電最佳化的正式研究，但從數值模型搬到實際裝置還涉及原生閘、雜訊和限制電路。[來源：Deller 等，Physical Review A 2023](https://journals.aps.org/pra/abstract/10.1103/PhysRevA.107.062410)

## 三、六個感測等級的具體編碼

先定義每個 sensor 的決策 $L_i\in\{0,1,2,3,4,5\}$，其中 **0 是關閉**。比較時必須固定同一組物理意義、覆蓋規則、路由限制和目標函數。不同 sensor 可以有不同 `radius_option_counts`，表格中的六級只是示例。

| 編碼 | 六級範例 0→5 | 每 sensor 變數 | 特性與代價 |
|---|---|---:|---|
| 二進制 compact | `000 001 010 011 100 101` | 3 bit | 最省 bit；`110/111` 無效；相鄰等級的 Hamming 距離可能大，如 3→4 需翻 3 bit |
| Gray code | `000 001 011 010 110 111` | 3 bit | 相鄰等級差 1 bit，仍有兩個無效碼；非相鄰距離不一定等於等級差 |
| one-hot（完整） | `100000 ... 000001` | 6 bit | 直觀，恰一個 1 的限制；多項式懲罰和交互作用可能多 |
| one-hot（關閉為全零） | `00000,10000,...,00001` | 5 bit | 本專案使用的變體；限制為「至多一個 1」，不是完整 one-hot |
| thermometer／domain-wall | `00000,10000,11000,11100,11110,11111` | 5 bit | 有序，合法碼之間 $d_H(a,b)=\lvert a-b\rvert$；需禁止 `10100` 類逆序碼 |
| 固定首位的累積碼 | `100000,110000,...,111111` | 6 bit，其中首位恆 1 | 專案既有草案；與前一列攜帶相同資訊，首位通常可刪除 |
| 三進制 compact | `00,01,02,10,11,12` | 2 trit | 有三個無效碼；若轉為 qubit/QUBO，仍須編譯成 bit 和限制，不能直接算「只需兩個 qubit」 |
| 一個六態 qudit | $\lvert0\rangle$ 至 $\lvert5\rangle$ | 1 個六態物理單元 | 數學上精簡，但硬體支援、讀出、閘保真度與耦合限制決定實際成本 |

以 100 sensor、每顆六級計：compact binary／Gray 為 **300 bit**，三進制為 **200 trit**，thermometer／關閉為全零的 one-hot 為 **500 bit**，專案固定首位草案為 **600 個儲存位置但只有 500 個可變位置**。這些只計 sensor 等級；完整 QUBO 另有覆蓋 slack、路由或其他輔助變數。對 $m$ 個選項，二進制為 $\lceil\log_2m\rceil$ bit、三進制為 $\lceil\log_3m\rceil$ trit、有序 thermometer 為 $m-1$ bit。少 bit 不保證較快：高階目標的降階、無效碼處理、QUBO 耦合密度與硬體嵌入都可能抵銷節省。

**專案特別要修正的表述**：根目錄的 [`wsn_quantum_cumulative_encoding.md`](./wsn_quantum_cumulative_encoding.md) 以固定首位 `1` 寫六級；現行 [`sensor_levels.py`](./codes/2027WSN/Qubo/sensor_levels.py) 實際使用 `L=0` 全零、`L=1` 首個位元為 1 的 **5 個可變 thermometer 位元**。後者較適合作 QUBO 基線。現行 `OneHotEncoding` 也是「關閉全零、開啟時至多一個 1」的 5 位版本。兩份材料描述的是同一類有序想法，但位元數和 0 的含義不能直接混用。

### 三進制要怎樣公平比較

可在**經典搜尋層**使用三進制：每顆 sensor 的兩個 trit 編成 0–5，6–8 視為無效；記錄重抽、修復或可行集合抽樣的成本。若要放進**二次 QUBO**，必須說明每個 trit 如何轉成二進制，例如每 trit 用兩個 bit 且排除 `11`，兩 trit 至少是四個 qubit/bit 再加限制（或改用完整六值 compact binary 的三 bit）。若用**原生 qutrit**，兩 qutrit 表示六級但有 9 個基態，也要處理 3 個無效態。把這三個研究對象混在同一「三進制比二進制省」主張中，會導致不公平的資源比較。

## 四、現有專案提供的起點

- [`codes/2027WSN/Qubo/sensor_levels.py`](./codes/2027WSN/Qubo/sensor_levels.py)：已把局部感測等級問題建成 QUBO，有 thermometer、one-hot、覆蓋 slack、`burden/fitness/routing` 代理目標、路由固定時的耗能表。這是研究核心起點。
- [`codes/2027WSN/Qubo/solvers.py`](./codes/2027WSN/Qubo/solvers.py)：有 Numba 模擬退火與最多 22 個 QUBO 變數的窮舉驗證。22 是程式預設上限，並非電腦或量子演算法的硬極限。
- [`codes/2027WSN/State/SensorEncoding.py`](./codes/2027WSN/State/SensorEncoding.py) 與 [`PriorityEncoding.py`](./codes/2027WSN/State/PriorityEncoding.py)：有既有完整 WSN 解碼器。`SensorEncoding` 每 sensor 包含感測選項和路由優先基因，不能把只有感測等級的 QUBO 結果直接宣稱為完整聯合最佳化。
- [`codes/2027WSN/maps/maps_100100100.json`](./codes/2027WSN/maps/maps_100100100.json)：列出六張 100 sensor／100 target、邊界 100 的測試圖。QUBO 子問題應在這些完整地圖上抽取區域，最終結果仍用完整覆蓋與路由評估器檢驗。
- [`codes/2027WSN/tests/smoke_qubo_sensor_levels.py`](./codes/2027WSN/tests/smoke_qubo_sensor_levels.py)：已有小題目能量及最優值驗證，適合擴展新編碼的正確性檢驗。

目前 QUBO 的 `routing` 是**固定路由樹的代理模型**；新解交回完整問題後，路由可能變動。論文主結果應採完整 WSN 的可行率、網路壽命和計算成本，代理 QUBO 能量只做診斷。這是程式實作直接可見的限制，不應包裝成全域精確路由模型。

## 五、硬體與可跑規模

以下是 2026-10-01 在**目前執行環境**讀到的規格：Intel Core i9-9900K（8 核／16 執行緒）、約 46 GiB RAM（當時約 44 GiB available）、NVIDIA GeForce RTX 2080 Ti（11,264 MiB VRAM，compute capability 7.5）。若這是遠端工作環境而非你的常用電腦，結論只適用於這台機器。這是規格推算，**沒有對新量子演算法實測執行時間**。

| 工作 | 建議規模與說明 |
|---|---|
| 量子啟發式機率／振幅抽樣 | 100 sensor × 5–6 等級、數十到數百候選、跨六張地圖多 seed 可行；主要瓶頸是每次完整 WSN fitness 和路由重算，不是儲存振幅 |
| 局部 QUBO + 經典模擬退火 | 從 3–10 sensor 的局部區域起步；再測 20、50 sensor。每個變數可能衍生覆蓋 slack；量測實際 QUBO 變數、非零耦合、每秒評估數和全圖壽命後，再決定放大 |
| QUBO 窮舉作 oracle | 目前程式設 `max_variables=22`；適合驗證小區域，不適合 100 sensor |
| 精確 statevector 的 qubit 電路 | complex128 狀態向量單份記憶體約 $16\times2^n$ byte；28/29/30/31 qubit 約 4/8/16/32 GiB。RTX 2080 Ti 上 29 qubit 已接近可用 VRAM 上限，實際含工作空間宜先以 **24–27 qubit** 試；CPU 先以 **26–29 qubit** 試，30+ 需謹慎實測 |
| 原生 qutrit statevector 的數值模擬 | 單份 $16\times3^t$ byte；18/19/20 qutrit 約 5.77/17.32/51.96 GiB。以本機 RAM，先以 **12–17 qutrit** 試；20 qutrit 僅向量本身就超過 RAM |
| 100 sensor 直接基底電路 | 六級 compact binary 就要 300 qubit；thermometer 要 500 qubit（另加 ancilla）。一般精確 statevector 在此機器完全不可行 |

記憶體值是單一狀態向量的**理論下限**，未包含電路、暫存、梯度、shots、雜訊、複製、OS 和 Python 物件。Qiskit Aer 的官方文件列出 statevector 與 matrix-product-state 等模擬器；GPU 支援依模擬方法和安裝版本而異，MPS 不支援 Aer GPU，且 MPS 的優勢依糾纏程度而定，不能據此宣稱任意 300-qubit QAOA 可模擬。[來源：Qiskit AerSimulator 文件](https://qiskit.github.io/qiskit-aer/stubs/qiskit_aer.AerSimulator.html)

對比之下，500 個二元變數的**稠密 QUBO 係數矩陣**約 $500^2\times8=2$ MB（float64），本機記憶體不是主要障礙；然而目前 SA 核心在每一次翻轉後要更新長度 $n$ 的 field，約隨 `reads × sweeps × n²` 增長，重複完整 fitness 也會耗時。請用 profiling 報實測，不以記憶體可放下推論演算法很快。

## 六、近年研究與可切入的缺口（2023–2026）

| 年份／研究 | 文獻的實際範圍 | 對本題的啟示 |
|---|---|---|
| 2023 Deller 等：qudit QAOA | 研究多態系統的整數最佳化、限制與圖著色／充電例子 | 支持比較三態／六態形式，但不能直接代表現有 GPU 上的物理 qutrit。[論文](https://journals.aps.org/pra/abstract/10.1103/PhysRevA.107.062410) |
| 2024 Kikuchi 等：domain-wall 與 one-hot | 比較數位 Ising 機的編碼、懲罰與求解時間；結果依問題與參數 | 有序編碼值得比較，不能預先假定一律勝出。[論文](https://arxiv.org/abs/2410.11198) |
| 2024 Rathee 等：WSN 量子啟發式 GA | 研究多 sink 佈置與能耗平衡 | WSN 加「量子啟發式」已有先例；本題要突出感測**多等級、覆蓋與路由**的不同決策。[論文](https://www.sciencedirect.com/science/article/abs/pii/S1570870523002706) |
| 2025 Wang 等：WSN QHHO + DRL | 用量子啟發式方法做 clustering、DRL 做 routing | 單純混搭一個量子啟發式和另一演算法的新意偏弱；需對編碼和限制做消融。[論文](https://www.sciencedirect.com/science/article/pii/S1570870525001623) |
| 2025 量子退火 QUBO benchmark | 報告特定大且稠密 QUBO 的量子退火／經典比較 | 可借基準設計，不可把別的 QUBO 結果套用成 WSN 上的量子優勢。[論文](https://www.nature.com/articles/s41534-025-01020-1) |
| 2026 Mahanta 等：量子啟發式 WSN 混合框架 | clustering、routing 與壽命，包含對機率編碼的消融 | 已有相近名稱與主題；本專案的差異須具體到**有序等級編碼＋局部 QUBO＋全網驗證**。[論文](https://www.nature.com/articles/s41598-026-57702-z) |
| 2026 QOBLIB 基準庫 | 提倡跨量子與經典求解器公平比較，提供基準、解與資料 | 論文需固定硬體、時間預算、資料分割、實驗種子並報可行率。[論文](https://www.nature.com/articles/s43588-026-00991-1) |

較早但重要的基礎：domain-wall 在量子退火硬體與 one-hot 的對比已有 2021 年工作，因此**不能把 domain-wall 本身當作新發明**。[來源：Performance of Domain-Wall Encoding for Quantum Annealing](https://arxiv.org/abs/2102.12224) 近年的 QAOA／量子退火研究對優勢的報告取決於問題類別、基線、成本定義與硬體；本題在沒有實際 WSN 比較之前不主張「量子優勢」。[來源：QOBLIB](https://www.nature.com/articles/s43588-026-00991-1)

## 七、碩士題目評估與可檢驗貢獻

| 候選題目 | 新意與實際貢獻 | 本機可行度 | 主要風險 | 建議 |
|---|---|---:|---|---|
| A. 有序／混合進制編碼的 WSN 局部 QUBO | 同一目標下建立完整的編碼、限制與求解成本比較；依 sensor 選項數自適應選碼；把局部解放回全網驗證 | 高 | 新編碼降階與修復成本可能吃掉位元節省 | **主題首選** |
| B. 量子啟發式多值機率模型 + 區域搜尋 | 設計保持合法等級的抽樣／更新和拓樸感知局部變異；比較相同評估次數的普通 categorical EDAs、GA、SA-SETS | 高 | 若只換成振幅記號，難證明新意 | 可作 A 的第二方法或獨立主題 |
| C. 三態／多態 QAOA 的 WSN 微型子問題 | 比較 qutrit 與 qubit 映射的態空間、閘數、深度、無效態、最優率 | 中，限微型 | 模擬尺度小；實機限制與噪聲；難連結全圖壽命 | 作探索章節 |
| D. 完整 100 sensor 量子加速 WSN | 若能有真機、合理嵌入與強經典基線，潛在價值高 | 低 | 本機不能精確模擬；目前沒有量子處理器資源證據 | 不建議作碩士主承諾 |

主題 A 的**可檢驗研究問題**：

1. 對不同等級數、區域大小和覆蓋重疊度，各編碼的 QUBO 變數數、非零耦合數、無效解率和 penalty 敏感度如何變化？
2. 在相同完整 WSN fitness 評估次數與相同 wall-clock 限制下，哪種編碼改善可行率、單次排程成本及整體壽命？
3. 感測器的不同選項數與覆蓋拓樸能否預測適合的編碼，讓**自適應混合進制**優於固定單一編碼？這需要在未用來選規則的測試地圖上驗證。
4. 固定路由的 QUBO 代理與全網重新路由之間差距多大？能否用代價低的路由敏感項縮小落差？

即使最後發現 compact binary 或普通 GA 最好，**清楚的反例、限制分析和可重現基準仍可形成紮實碩士成果**。是否足以畢業或投稿，仍取決於系所標準、指導教授與實驗結果；不能由文獻數量保證。

## 八、建議實驗設計與里程碑

1. **定義同一問題**：固定關閉值、每顆 sensor 合法等級、覆蓋與路由限制、完整壽命指標；列出各編碼的解碼、修復與 penalty。不要把不同代理目標的結果混在編碼比較。
2. **正確性**：對 2–4 sensor 小區域枚舉所有合法等級，逐一對 QUBO 能量；測最小 QUBO 能量、無效碼、覆蓋和固定路由耗能。延續現有 22 變數窮舉 oracle。
3. **第一階段基準**：區域大小 3、5、8、10；至少比較現有 thermometer、one-hot，新增 compact binary、Gray，再加入三進制經典抽樣。列出變數、slack、耦合與建立／求解時間。此階段先檢查 penalty 網格與搜尋預算敏感度。
4. **第二階段全圖**：用六張 100/100 地圖，另建立與訓練／調參地圖分離的測試組；比較無局部 QUBO 的 SA-SETS／GA、相同局部搜尋但無新編碼的基線、各編碼固定版與自適應版。記錄多 seed 的全網壽命、可行率、單次排程耗能、wall-clock、完整 fitness 次數與失敗個案。
5. **消融**：只換編碼、只換區域挑選、只換代理目標、全部結合；固定其他設定。統計報中位數、四分位區間或信賴區間與成對地圖／seed 差值，不只挑最好的一次。
6. **小型量子章節（選做）**：抽取 QUBO 變數 8–20 的相同局部例；與窮舉、經典 SA 比較 QAOA 的可行率、最佳能量、電路深度、shots 與總時間。若資源不足，停在經典編碼主題並完整寫明尺度界線。

最重要的判定門檻是：**新方法必須在未見地圖上，於相同預算下穩定改善至少一個有意義的 WSN 指標，且沒有不可接受的可行率／時間退化；或提出能解釋何時有效、何時失效的可靠規律。**若沒有這些結果，題目可以縮成高品質的編碼基準與問題結構分析，但不應宣稱已提升網路壽命。

## 九、可直接採用的題目名稱

> **中文**：具覆蓋與路由限制之無線感測網路感測等級混合進制編碼與 QUBO 分區最佳化
>
> **English**: Mixed-Radix Encoding and Decomposed QUBO Optimization for Coverage- and Routing-Constrained Wireless Sensor Network Scheduling

若實驗重心轉向量子啟發式搜尋，可改為「有序多值機率編碼之量子啟發式無線感測網路壽命最佳化」，但摘要須明說它在經典硬體執行，並與一般機率模型作公平消融。

## 參考資料與查證範圍

本文外部來源均為原始研究論文／出版頁或 Qiskit 官方文件；連結置於相關敘述旁。專案能力和限制由本文列出的本地原始碼、測試與地圖讀取；硬體規格由本環境 `lscpu`、`free -h`、`nvidia-smi --query-gpu=name,memory.total,compute_cap` 於研究當日取得。可跑規模是記憶體公式與保守工程估算，並非新演算法 benchmark 的實測成績。
