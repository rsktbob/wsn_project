# 代理模型 WSN 論文與目前環境比較

日期：2026-10-01。

## 結論

剛才提到的 BVSSA 論文，與本專案不是同一個最佳化問題。該文的 WSN 案例調整三維部署位置以改善覆蓋；本專案的候選評估主要是排層／優先序解碼、路由建構與單輪能耗評分。

目前沒有查到足以比較兩者「單次 fitness 耗時」的論文數據。因此不能宣稱該文的 WSN 評分一定很慢，或推論本專案也需要代理模型。先前列舉封包模擬、完整生命週期、真實硬體量測等，只是可能昂貴的其他 WSN 設定，不是已核實的 BVSSA 實驗內容。

## 1. 論文與可核實內容

Jeng-Shyang Pan et al. **Bimodal valley switching surrogate-assisted optimization and its application for wireless sensor networks.** Applied Soft Computing, 187, 114365，期刊卷期為 2026 年 2 月，DOI 含 2025。

- [出版商頁面](https://www.sciencedirect.com/science/article/pii/S1568494625016783)
- [章節摘要及實驗設定](https://www.sciencedirect.com/science/article/abs/pii/S1568494625016783)
- [DOI](https://doi.org/10.1016/j.asoc.2025.114365)

已核實：

- WSN 案例是三維部署位置與覆蓋最佳化。
- 實驗節點數為 30／35／40／45；感測半徑 R 的案例值為 3／7／10；各算法獨立執行 10 次。
- 全域代理使用 Kriging，局部代理使用 RBF；論文提出搜尋區域切換策略。

未核實：完整 Eq. (34) 及後續公式、空間邊界、覆蓋離散化／取樣密度、精確決策維度、單次真實評估時間、WSN 專屬總執行時間與代理訓練占比。沒有取得完整全文，不能聲稱作者沒有報告這些項目，也不能補造數字。

公開內容不足以證明其 WSN 案例使用封包級模擬、碰撞重傳、SINR、完整壽命 rollout 或真實設備實驗。半徑 R 出現在不同實驗設定中，也不等於它像本專案一樣是每顆感測器可選的排層基因。

## 2. 專案目前實作：直接查閱程式

以下以 `codes/2027WSN` 為準。實際某一次實驗的參數可以覆寫預設值，本次未指定某一筆 run，也未做耗時計量。

### 地圖與變數

- 預設實驗為邊長 100 的二維地圖、100 sensors、100 targets；地圖清單含 MAP01～MAP06。資料 CSV 是兩維座標。
- 使用者討論的 0／1／2 是三態研究設定。程式目前預設離散物理感測半徑為 `[0, 3, 6, 9, 12, 15]`，並非固定只有三態；此外支援不同 sensing mode。
- `SensorEncoding` 每顆保存感測選項和 0～9 的優先序基因。優先序會影響覆蓋選擇及加入路由的順序。
- 解碼器預設 v3：依優先序挑選能增加覆蓋的節點、移除可替代冗餘，再建路由。原始基因與最終排層不一定一樣。
- 一次內層排層搜尋不直接改變座標；完整 lifetime 流程另有可選的移動修復與拓樸重建，不能說整個專案完全不支援移動。

程式依據：

- [實驗預設](codes/2027WSN/experiments/config.py)
- [地圖清單](codes/2027WSN/maps/maps_100100100.json)
- [地圖座標](codes/2027WSN/data/100100100_MAP01/sensor.csv)
- [半徑設定](codes/2027WSN/Problem/Problem.py)
- [編碼與解碼](codes/2027WSN/State/SensorEncoding.py)
- [移動修復及重建](codes/2027WSN/experiments/problem_setup.py)

### 一次 fitness 的實際內容

實驗預設選擇 FitnessServiceV2。對完全覆蓋、連通且能量可行的 state，預設評分是：

```text
quality = 0.3 × (1 − 全網單輪耗能／目前總能量)
        + 0.7 × (1 − 最差目標區域的單輪能量耗損比例)
```

目標區域的能量透過 `target_sensor_mask` 聚合；這個 mask 表示節點在其可用感測選項中是否能覆蓋目標，不是「當輪實際選中節點」的 mask。未覆蓋、斷線或能量不足的 state 有各自的評分分支。v1／v3 的處理不同，重現必須記錄版本。

計算上的優點：

1. `coverage_table[target, sensor, level]` 在 Problem 建立時預先計算。固定位置的候選換排層時，主要查表，不必每次重新建全部幾何關係。
2. 裝置距離另有預計算矩陣。
3. 感測耗能為半徑平方乘係數；路由耗能依負載、距離與電路成本計算。
4. 解碼 state 可重用 `tx_load`；Numba 可用時，有覆蓋、解碼及能耗的編譯核心。

這些結構與使用者描述「一次 fitness 很快」相符，但程式閱讀不能取代計時，不在此提供微秒／毫秒數字。

程式依據：

- [fitness v2](codes/2027WSN/Problem/services/fitness_servicev2.py)
- [覆蓋查表](codes/2027WSN/Problem/services/coverage_service.py)
- [能耗公式與快取](codes/2027WSN/Problem/services/energy_service.py)
- [Numba 評估核心](codes/2027WSN/Problem/services/evaluation_kernels.py)

### 完整 lifetime 不是每個候選的 fitness

外層 `run_lifetime_case` 呼叫最佳化器取得 state，再由 `_advance_lifetime` 扣除電量、累計運作時間，必要時重新最佳化或移動。

因此，整場 lifetime 實驗花費很久，不代表內層每個候選都做了一次完整 lifetime 模擬。若要學習預測完整生命週期，那是另一個預測目標，需要重新定義訓練資料與評估標準。

依據：[生命週期 runner](codes/2027WSN/experiments/runner.py)。

## 3. 直接比較

| 面向 | BVSSA 論文可核實內容 | 目前專案 |
|---|---|---|
| WSN 工作 | 三維部署覆蓋最佳化 | 給定當前地圖的排層、優先序與路由评估 |
| 空間 | 三維 | 當前檢查的資料為二維 |
| 節點規模 | 30～45 的四組設定 | 預設 100 |
| 主要目標 | 覆蓋改善 | 當輪覆蓋／連通可行性、耗能與目標區域能量平衡；外層觀察 lifetime |
| 半徑 | 不同實驗使用 R=3／7／10 | 每顆可選感測選項；預設六態，三態是另行研究設定 |
| 幾何關係重用 | 部署位置改變會改變覆蓋關係；具體實作快取未核實 | 固定位置的內層搜尋可查預先計算表 |
| 真實評估成本 | 本次未取得單次耗時與 WSN 總時間細節 | 使用者回報很快；程式有查表、Numba 和解析式能耗，本次未計時 |
| 是否需要代理 | 該文使用代理，不能據此證明所有 WSN 都需要 | 目前沒有證據顯示以代理取代快速 fitness 會更划算 |

部署位置改變導致覆蓋關係改變，是幾何推論；不能進一步當成本文一定使用昂貴模擬、或其運算一定比本專案慢的證據。

## 4. 是否值得使用代理：比較總成本

同等解品質下，近似的成本比較應為：

```text
直接搜尋成本 = N_direct × t_fitness + T_direct_search
代理搜尋成本 = N_true × t_fitness + T_fit + T_predict + T_surrogate_search
```

其中 `t_fitness` 應包含實際候選所需的解碼、路由和評分，而不只某個加權公式。重複查快取與真正新候選也應分開計時；Numba 第一次編譯應與暖機後評估區分。

省下的真實評估時間必須超過訓練、推論與其他新增搜尋成本，才可能帶來時間優勢。即使真實評估次數較少，也不能直接宣稱總時間更短。代理誤差及所得解品質還需另外驗證。

對當前專案的建議：先保留快速的直接評分，改善多節點聯合搜尋、候選去重、可重用計算與搜尋操作選擇。若以後改成每個候選都要跑昂貴的隨機通訊模擬、長期 rollout 或實機量測，再重新評估代理的收益。

## 5. 最終判斷

這篇可以證明「有研究將代理模型應用於 WSN 部署覆蓋」，不能證明「你的 WSN fitness 適合被代理取代」。目前的實作與使用者回報，支持先把研究重點放在更有效的搜尋，而非加入額外的分數預測模型。
